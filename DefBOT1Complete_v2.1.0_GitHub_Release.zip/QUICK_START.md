# ⚡ QUICK START - DefBOT1Complete ⚡

## 🚀 **60-SECOND DEPLOYMENT:**

### 1️⃣ **FLASH FIRMWARE** (30 seconds)
```bash
# Download DefBOT1Complete_FINAL_AGGRESSIVE.bin
# Open M5Burner → Select AtomS3 → Load .bin → BURN
```

### 2️⃣ **POWER ON** (5 seconds)  
```bash
# Connect USB-C power
# Device shows: "DEFENDER" boot screen
# Face turns CYAN → Ready to scan
```

### 3️⃣ **AUTO-ATTACK** (25 seconds)
```bash
# Scans every 30 seconds for open WiFi
# Face turns ORANGE → Target found
# Face turns RED → Attack in progress  
# Face turns GREEN → Evil portal destroyed
```

---

## 🎯 **WHAT TO EXPECT:**

### ✅ **SUCCESS INDICATORS:**
- **Cyan Face** - Actively scanning for threats
- **Orange Face** - Open WiFi detected, preparing attack
- **Red Face** - Connected and spamming evil portal
- **Green Face** - Mission accomplished, threat neutralized

### 📊 **Serial Monitor Output:**
```
🛡️ DEFENDER PARASITE v1.0
🔍 Found 8 networks
🔍 Found OPEN network: 'EvilPortal'  
🎯 TARGETING OPEN NETWORK: EvilPortal
🚨 1 THREATS DETECTED!
🚨 AUTO-CONNECTING TO EVIL PORTAL!
✅ Connected! Starting credential flood...
💥 Sending fake login 1/50...
💥 Sending fake login 2/50...
```

---

## 💡 **TROUBLESHOOTING:**

### ❓ **Device not detecting open WiFi?**
- ✅ Ensure open networks are nearby (no password)
- ✅ Check serial monitor for scan results
- ✅ Wait 30+ seconds between scans

### ❓ **Face stuck on orange?** 
- ✅ May be connecting to weak signal
- ✅ Move closer to target network
- ✅ Check if network actually accepts connections

### ❓ **No attack happening?**
- ✅ Target may not be evil portal (harmless)
- ✅ Legitimate websites reject fake credentials
- ✅ Only evil portals accept spam (and get overwhelmed)

---

## 🔧 **ADVANCED OPTIONS:**

### 📝 **Customize Safe Networks:**
Edit `isEvilPortal()` function to exclude your trusted open networks:
```cpp
if (ssid.indexOf("yourtrustedwifi") != -1) return false;
```

### ⚡ **Adjust Attack Speed:**
Modify spam timing in `attackEvilPortal()`:
```cpp  
if (millis() - lastSpam > 250) {  // Faster: 250ms vs 500ms
```

### 🎨 **Change Face Expressions:**
Customize emotions in `updateFace()` function.

---

## 📱 **COMPATIBLE DEVICES:**

- ✅ **M5Stack AtomS3** (Primary target)
- ⚠️ **Other ESP32-S3** (may need pin adjustments)  
- ❌ **ESP32 Classic** (incompatible - needs S3 features)

---

**🔥 READY TO DEPLOY IN UNDER 60 SECONDS! 🔥**

**Just flash, power on, and watch it automatically protect users from evil portals!**